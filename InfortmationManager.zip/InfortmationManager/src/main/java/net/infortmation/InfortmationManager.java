package net.infortmation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfortmationManager {

	public static void main(String[] args) {
		SpringApplication.run(InfortmationManager.class, args);

	}

}
